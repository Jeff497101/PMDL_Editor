package com.pmdleditor.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int OPEN = 1, SAVE = 2;

    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private byte[] pending;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xFF151B28);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "PMDLAndroid");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                boolean image = false;
                for (String type : params.getAcceptTypes()) if (type.startsWith("image/")) image = true;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // Android no conoce .pmdl ni .PCK1, así que se permite cualquier archivo.
                intent.setType(image ? "image/*" : "*/*");
                try {
                    startActivityForResult(intent, OPEN);
                } catch (ActivityNotFoundException e) {
                    chooser.onReceiveValue(null);
                    chooser = null;
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Funciones que la página puede llamar. */
    public class Bridge {
        @JavascriptInterface
        public void save(final String name, final String type, String data) {
            final byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            runOnUiThread(() -> {
                pending = bytes;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(type);
                intent.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(intent, SAVE);
                } catch (ActivityNotFoundException e) {
                    saved("error");
                }
            });
        }
    }

    private void saved(String result) {
        pending = null;
        web.evaluateJavascript("window.pmdlSaved&&window.pmdlSaved(" + JSONObject.quote(result) + ")", null);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OPEN && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            chooser = null;
        } else if (request == SAVE) {
            if (result != RESULT_OK || data == null || data.getData() == null) {
                saved("cancel");
            } else if (pending == null) {
                saved("error");
            } else {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    out.write(pending);
                    out.flush();
                    saved("ok");
                } catch (Exception e) {
                    saved("error");
                }
            }
        }
    }

    /** Atrás: primero cierra el visor ampliado; si no, pregunta antes de salir. */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.pmdlBack?window.pmdlBack():false", handled -> {
            if ("true".equals(handled)) return;
            new AlertDialog.Builder(this)
                    .setMessage("¿Salir de PMDL Editor? Los cambios sin guardar se perderán.")
                    .setPositiveButton("Salir", (dialog, which) -> finish())
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }
}
